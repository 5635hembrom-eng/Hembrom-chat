package com.hembrom.chat

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Green = Color(0xFF075E54)
private val Pale = Color(0xFFEAF5F1)
private val Ink = Color(0xFF172B27)

data class ChatContact(val name: String, val message: String, val time: String, val unread: Int, val initials: String)
data class ChatMessage(val text: String, val mine: Boolean, val time: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = lightColorScheme(primary = Green, secondary = Color(0xFF25A56A), background = Color(0xFFF7FAF9))) { HembromChatApp() } }
    }
}

@Composable
fun HembromChatApp() {
    val contacts = remember { listOf(
        ChatContact("Amit Kumar", "ठीक है, कल बात करते हैं।", "9:41 PM", 2, "AK"),
        ChatContact("Riya", "फोटो अच्छी है 😊", "8:20 PM", 0, "R"),
        ChatContact("Study Group", "Notes भेज देना", "7:15 PM", 4, "SG"),
        ChatContact("Rahul Hembrom", "ऑनलाइन था अभी", "Yesterday", 0, "RH"),
        ChatContact("Family", "घर कब आ रहे हो?", "Yesterday", 1, "F")
    ) }
    var selected by remember { mutableStateOf<ChatContact?>(null) }
    var query by remember { mutableStateOf("") }
    var showProfile by remember { mutableStateOf(false) }
    if (selected != null) {
        ChatScreen(contact = selected!!, onBack = { selected = null })
    } else if (showProfile) {
        Scaffold(topBar = { TopAppBarCompat("आपकी प्रोफ़ाइल", onBack = { showProfile = false }) }) { pad ->
            Column(Modifier.padding(pad).fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Avatar("H", 88); Spacer(Modifier.height(16.dp)); Text("Hembrom Chat यूज़र", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("डेमो प्रोफ़ाइल • Firebase जोड़ना बाकी है", color = Color.Gray)
                Spacer(Modifier.height(24.dp)); Text("अकाउंट सेटिंग्स", fontWeight = FontWeight.Bold)
                Text("लॉगिन, OTP सत्यापन और प्रोफ़ाइल सेव करने के लिए Firebase कॉन्फ़िगरेशन आवश्यक है।", modifier = Modifier.padding(top = 8.dp))
            }
        }
    } else {
        Scaffold(topBar = {
            Column(Modifier.fillMaxWidth().background(Green).padding(start = 18.dp, end = 12.dp, top = 14.dp, bottom = 12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Hembrom Chat", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                        Text("संदेश • जुड़ाव • दोस्ती", color = Color.White.copy(alpha = .8f), fontSize = 12.sp)
                    }
                    IconButton(onClick = { showProfile = true }) { Avatar("H", 38) }
                    IconButton(onClick = { }) { Icon(Icons.Default.MoreVert, contentDescription = "More", tint = Color.White) }
                }
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth(), placeholder = { Text("चैट खोजें", color = Color.Gray) }, leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) }, singleLine = true, shape = RoundedCornerShape(24.dp), colors = OutlinedTextFieldDefaults.colors(focusedContainerColor = Color.White, unfocusedContainerColor = Color.White, focusedBorderColor = Color.White, unfocusedBorderColor = Color.White))
            }
        }) { padding ->
            Column(Modifier.padding(padding).fillMaxSize()) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("आपकी चैट", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Ink)
                    Surface(color = Pale, shape = RoundedCornerShape(50)) { Text("DEMO MODE", modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp), color = Green, fontSize = 10.sp, fontWeight = FontWeight.Bold) }
                }
                LazyColumn(contentPadding = PaddingValues(bottom = 20.dp)) {
                    items(contacts.filter { it.name.contains(query, true) || it.message.contains(query, true) }) { contact -> ContactRow(contact) { selected = contact } }
                }
                Surface(color = Color(0xFFFFF4D8), modifier = Modifier.fillMaxWidth()) {
                    Text("यह UI प्रोटोटाइप है। असली अकाउंट और ऑनलाइन चैट के लिए Firebase सेटअप करना होगा।", modifier = Modifier.padding(12.dp), fontSize = 12.sp, color = Color(0xFF72531A))
                }
            }
        }
    }
}

@Composable
fun ContactRow(contact: ChatContact, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Avatar(contact.initials, 54)
        Spacer(Modifier.width(13.dp))
        Column(Modifier.weight(1f)) {
            Text(contact.name, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, color = Ink)
            Spacer(Modifier.height(4.dp)); Text(contact.message, color = Color.Gray, fontSize = 13.sp, maxLines = 1)
        }
        Column(horizontalAlignment = Alignment.End) {
            Text(contact.time, fontSize = 11.sp, color = if (contact.unread > 0) Green else Color.Gray)
            if (contact.unread > 0) { Spacer(Modifier.height(6.dp)); Surface(color = Color(0xFF25A56A), shape = CircleShape) { Text("${contact.unread}", color = Color.White, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)) } }
        }
    }
    HorizontalDivider(color = Color(0xFFE9EFED), thickness = .6.dp, modifier = Modifier.padding(start = 82.dp))
}

@Composable
fun Avatar(label: String, size: Int) {
    Surface(modifier = Modifier.size(size.dp), shape = CircleShape, color = Color(0xFFD8EEE6)) {
        Box(contentAlignment = Alignment.Center) { Text(label.take(2), color = Green, fontWeight = FontWeight.Bold, fontSize = (size / 3.1).sp) }
    }
}

@Composable
fun ChatScreen(contact: ChatContact, onBack: () -> Unit) {
    val messages = remember(contact.name) { mutableStateListOf(
        ChatMessage("नमस्ते! कैसे हो?", false, "9:35 PM"),
        ChatMessage("मैं ठीक हूँ 😊 आप बताइए।", true, "9:37 PM"),
        ChatMessage(contact.message, false, contact.time)
    ) }
    var draft by remember { mutableStateOf("") }
    Scaffold(topBar = {
        Row(Modifier.fillMaxWidth().background(Green).padding(horizontal = 4.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White) }
            Avatar(contact.initials, 40); Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) { Text(contact.name, color = Color.White, fontWeight = FontWeight.SemiBold); Text("डेमो चैट", color = Color.White.copy(alpha = .75f), fontSize = 11.sp) }
            IconButton(onClick = {}) { Icon(Icons.Default.Call, contentDescription = "Call", tint = Color.White) }
            IconButton(onClick = {}) { Icon(Icons.Default.MoreVert, contentDescription = "More", tint = Color.White) }
        }
    }) { padding ->
        Column(Modifier.padding(padding).fillMaxSize().background(Color(0xFFF2F6F4))) {
            LazyColumn(Modifier.weight(1f).fillMaxWidth(), contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(messages) { msg ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (msg.mine) Arrangement.End else Arrangement.Start) {
                        Column(Modifier.widthIn(max = 300.dp).background(if (msg.mine) Color(0xFFD9FDD3) else Color.White, RoundedCornerShape(16.dp)).padding(horizontal = 13.dp, vertical = 9.dp)) {
                            Text(msg.text, color = Ink, fontSize = 15.sp); Spacer(Modifier.height(4.dp)); Text(msg.time, color = Color.Gray, fontSize = 10.sp, modifier = Modifier.align(Alignment.End))
                        }
                    }
                }
            }
            Row(Modifier.fillMaxWidth().background(Color.White).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(value = draft, onValueChange = { draft = it }, modifier = Modifier.weight(1f), placeholder = { Text("संदेश लिखें…") }, shape = RoundedCornerShape(24.dp), singleLine = true)
                Spacer(Modifier.width(8.dp))
                IconButton(onClick = { if (draft.isNotBlank()) { messages.add(ChatMessage(draft.trim(), true, "अभी")); draft = "" } }, modifier = Modifier.background(Green, CircleShape).size(48.dp)) { Icon(Icons.Default.Send, contentDescription = "Send", tint = Color.White) }
            }
            Text("डेमो संदेश केवल इस स्क्रीन पर रहते हैं; सर्वर पर सेव नहीं होते।", fontSize = 10.sp, color = Color.Gray, modifier = Modifier.fillMaxWidth().background(Color.White).padding(bottom = 6.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TopAppBarCompat(title: String, onBack: () -> Unit) {
    TopAppBar(title = { Text(title) }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back") } })
}
