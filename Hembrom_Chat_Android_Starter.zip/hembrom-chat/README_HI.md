# Hembrom Chat — Android starter project

यह Android Studio के लिए शुरुआती प्रोजेक्ट है। अभी इसमें आधुनिक चैट-लिस्ट UI, डेमो चैट स्क्रीन और FCM संदेश प्राप्त करने की सर्विस का आधार है। **यह अभी production-ready messaging app या APK नहीं है।** डेमो संदेश सर्वर पर सेव नहीं होते।

## APK की जाँच
अपलोड की गई `base.apk` में WhatsApp-संबंधित क्लास/लाइब्रेरी स्ट्रिंग्स मिली हैं। यह WhatsApp से जुड़ी APK होने का मजबूत संकेत है; package name और signing certificate की पुष्टि अलग से करनी होगी। Hembrom Chat स्वतंत्र ऐप है और अपलोड की गई ऐप का कोड/डेटा कॉपी नहीं करता।

## Android Studio में खोलें
1. इस ZIP को extract करें।
2. Android Studio में `hembrom-chat` फ़ोल्डर खोलें।
3. Android SDK Platform 35 और compatible Android Gradle Plugin डाउनलोड होने दें।
4. Gradle sync करें।
5. फोन पर चलाने के लिए Run दबाएँ।

इस वातावरण में Android SDK/Gradle build tool उपलब्ध नहीं था, इसलिए यहाँ से APK compile या test नहीं किया गया।

## Firebase कनेक्ट करना
1. Firebase Console में नया project बनाकर Android app ID `com.hembrom.chat` जोड़ें।
2. Firebase से `google-services.json` डाउनलोड करके `app/` में रखें।
3. Root `build.gradle.kts` में Google Services plugin version जोड़ें और `app/build.gradle.kts` में `id("com.google.gms.google-services")` लागू करें।
4. Firebase Authentication में Email/Password (या चुना हुआ sign-in तरीका) enable करें।
5. Firestore database बनाकर `firebase/firestore.rules` के नियमों की समीक्षा करके deploy करें।
6. Cloud Messaging और Android 13+ notification permission flow जोड़ें।
7. वास्तविक चैट के लिए संदेशों का Firestore read/write, participant authorization, unread count, pagination, reporting/blocking और push-notification server trigger लागू करना बाकी है।

## Admin panel
`admin-panel/index.html` केवल UI preview है, लाइव admin console नहीं। इसे सार्वजनिक रूप से deploy करने से पहले secure admin login, server-side authorization, audit logs और moderation backend जोड़ें। Firebase Admin SDK की private key को browser में कभी न रखें।

## Build APK
Firebase configuration और बाकी backend features जोड़ने के बाद Android Studio में **Build > Build APK(s)** चलाएँ। Release APK के लिए signing key बनाकर सुरक्षित रखें। इस starter ZIP में APK शामिल नहीं है।
